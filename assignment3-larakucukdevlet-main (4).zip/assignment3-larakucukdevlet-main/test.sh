cd src
javac given/*.java
cd ..
java -cp src given.AutograderMain
