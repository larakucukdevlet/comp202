package code;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import given.iMap;
import given.iBinarySearchTree;

/*
 * Implement a vanilla binary search tree using a linked tree representation
 * Use the BinaryTreeNode as your node class
 */

public class BinarySearchTree<Key, Value> implements iBinarySearchTree<Key, Value>, iMap<Key, Value> {
  
	protected BinaryTreeNode<Key,Value> rootNode;
	  protected Comparator<Key> comparator;
	  protected ArrayList<Key> keySet = new ArrayList<>();
	  protected ArrayList<BinaryTreeNode<Key,Value>> nodeList = new ArrayList<>();
	 
	
	  

	  /*public BinarySearchTree(Key k, Value v) {
	    this.rootNode = new BinaryTreeNode<>(k,v);
	    this.keySet.add(rootNode.getKey());
	  }*/
	  public ArrayList<Key> setKey(Key k,Value v) {
		  rootNode = new BinaryTreeNode<>(k,v);
		 keySet.add(rootNode.getKey());
		return keySet;		  
	  }

	  @Override
	  public Value get(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> foundNode = this.getNode(k);
	    if (Objects.isNull(foundNode)){
	      return null;
	    }
	    return foundNode.getValue();
	  }

	  @Override
	  public Value put(Key k, Value v) { if (this.rootNode == null) {
	        this.rootNode = new BinaryTreeNode<>(k, v);
	        this.keySet.add(k);
	        return null;
	    }
	    BinaryTreeNode<Key, Value> foundNode = this.getNode(k);
	    if (Objects.isNull(foundNode)) {
	        BinaryTreeNode<Key, Value> newNode = new BinaryTreeNode<>(k, v);
	        BinaryTreeNode<Key, Value> parent = this.getParent(this.rootNode);
	        if (this.comparator.compare(k, parent.getKey()) < 0) {
	            parent.setLeftChild(newNode);
	        } else {
	            parent.setRightChild(newNode);
	        }
	        this.keySet.add(k);
	        return null;
	    }
	    Value oldValue = foundNode.getValue();
	    foundNode.setValue(v);
	    return oldValue;
	    /*// TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> foundNode = this.getNode(k);
	    if (Objects.isNull(foundNode)){
	      return null;
	    }
	    Value oldValue = foundNode.getValue();
	    foundNode.setValue(v);
	    return oldValue;*/
	  }

	  @Override
	  public Value remove(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> foundNode = this.getNode(k);

	    if (Objects.isNull(foundNode)){
	      return null;
	    }

	    Value foundValue = foundNode.getValue();

	    if (!foundNode.hasRightChild() && foundNode.hasLeftChild()){
	      if (this.isLeftChild(foundNode)){
	        foundNode.getParent().setLeftChild(null);
	        foundNode.setParent(null);
	      }
	      else{
	        foundNode.getParent().setRightChild(null);
	        foundNode.setParent(null);
	      }
	    }
	    else if (!foundNode.hasLeftChild() && foundNode.hasRightChild()){
	      if (this.isLeftChild(foundNode)){
	        foundNode.getParent().setLeftChild(foundNode.getRightChild());
	      }
	      else{
	        foundNode.getParent().setRightChild(foundNode.getRightChild());
	      }
	      foundNode.getRightChild().setParent(foundNode.getParent());
	    }
	    else if (foundNode.hasLeftChild() && !foundNode.hasRightChild()){
	      if (this.isLeftChild(foundNode)){
	        foundNode.getParent().setLeftChild(foundNode.getLeftChild());
	      }
	      else{
	        foundNode.getParent().setRightChild(foundNode.getLeftChild());
	      }
	      foundNode.getLeftChild().setParent(foundNode.getParent());
	    }
	    else{
	      BinaryTreeNode<Key,Value> predecessor = this.ceiling(k);
	      Key pKey = predecessor.getKey();
	      Value pValue = predecessor.getValue();
	      this.remove(predecessor.getKey());
	      foundNode.setKey(pKey);
	      foundNode.setValue(pValue);
	    }

	    return foundValue;
	  }

	  @Override
	  public Iterable<Key> keySet() {
	    // TODO Auto-generated method stub
	    return this.keySet;
	  }

	  @Override
	  public int size() {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> startNode = this.rootNode;
	    return this.sizeHelper(startNode);
	  }

	  @Override
	  public boolean isEmpty() {
	    // TODO Auto-generated method stub
	    return Objects.isNull(this.rootNode);
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> getRoot() {
	    // TODO Auto-generated method stub
	    return this.rootNode;
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> getParent(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    return node.getParent();
	  }

	  @Override
	  public boolean isInternal(BinaryTreeNode<Key, Value> node) {
		  if(node==null) {
			  return false;
		  }
	    // TODO Auto-generated method stub
	    return !Objects.isNull(node);
	  }

	  @Override
	  public boolean isExternal(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
		  if(node==null) {
			  return false;
		  }
	    return Objects.isNull(node);
	  }

	  @Override
	  public boolean isRoot(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    return Objects.isNull(node.parent);
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> getNode(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> startNode = this.rootNode;
	    while (this.isInternal(startNode)){
	      if (this.getComparator().compare(k, startNode.getKey()) < 0){
	        startNode = startNode.getLeftChild();
	      }
	      else if (this.getComparator().compare(k, startNode.getKey()) > 0){
	        startNode = startNode.getRightChild();
	      }
	      else{
	        return startNode;
	      }
	    }
	    return null;
	  }

	  @Override
	  public Value getValue(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> foundNode = this.getNode(k);
	    if (Objects.isNull(foundNode)){
	      return null;
	    }
	    return foundNode.getValue();
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> getLeftChild(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
		 
	    return node.getLeftChild();
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> getRightChild(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    return node.getRightChild();
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> sibling(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    if (this.isLeftChild(node)){
	      if (this.isInternal(node.getParent().getRightChild())){
	        return node.getParent().getRightChild();
	      }
	      else{
	        return null;
	      }
	    }
	    else if (this.isRightChild(node)) {
	      if (this.isInternal(node.getParent().getLeftChild())) {
	        return node.getParent().getLeftChild();
	      } else {
	        return null;
	      }
	    }
	    else{
	      return null;
	    }
	  }

	  @Override
	  public boolean isLeftChild(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    return node.parent.getLeftChild().equals(node);
	  }

	  @Override
	  public boolean isRightChild(BinaryTreeNode<Key, Value> node) {
	    // TODO Auto-generated method stub
	    return node.parent.getRightChild().equals(node);
	  }

	  @Override
	  public List<BinaryTreeNode<Key, Value>> getNodesInOrder() {
	    // TODO Auto-generated method stub
	    this.getNodesInOrderHelper(this.rootNode);
	    return this.nodeList;
	  }

	  @Override
	  public void setComparator(Comparator<Key> C) {
	    // TODO Auto-generated method stub
	    this.comparator = C;
	  }

	  @Override
	  public Comparator<Key> getComparator() {
	    // TODO Auto-generated method stub
	    return this.comparator;
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> ceiling(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> startNode = this.rootNode;
	    return this.ceilingHelper(k,startNode);
	  }

	  @Override
	  public BinaryTreeNode<Key, Value> floor(Key k) {
	    // TODO Auto-generated method stub
	    BinaryTreeNode<Key,Value> startNode = this.rootNode;
	    return this.floorHelper(k,startNode);
	  }

	  public BinaryTreeNode<Key, Value> ceilingHelper(Key k, BinaryTreeNode<Key, Value> node){
	    if(this.isExternal(node)){
	      return null;
	    }

	    if (node.getKey().equals(k)){
	      return node;
	    }

	    if (this.getComparator().compare(node.getKey(), k) < 0){
	      return this.ceilingHelper(k,node.getRightChild());
	    }

	    BinaryTreeNode<Key, Value> ceiling = this.ceilingHelper(k,node.getLeftChild());
	    Key ceilingKey = ceiling.getKey();

	    if (this.getComparator().compare(ceilingKey,k) >= 0){
	      return ceiling;
	    }
	    else{
	      return node;
	    }
	  }

	  public BinaryTreeNode<Key,Value> floorHelper(Key k, BinaryTreeNode<Key,Value> node){
	    if(this.isExternal(node)){
	      return null;
	    }

	    if (node.getKey().equals(k)){
	      return node;
	    }

	    if (this.getComparator().compare(node.getKey(), k) > 0){
	      return this.floorHelper(k,getLeftChild(node));
	    }

	    BinaryTreeNode<Key, Value> floor = this.floorHelper(k,node.getRightChild());
	    Key floorKey = floor.getKey();

	    if ((this.getComparator().compare(floorKey,k) <= 0) && this.isInternal(floor)){
	      return floor;
	    }
	    else{
	      return node;
	    }
	  }

	  public int sizeHelper(BinaryTreeNode<Key,Value> startNode){
	    if (this.isExternal(startNode)){
	      return 0;
	    }

	    return 1 + this.sizeHelper(getLeftChild(startNode)) + this.sizeHelper(getRightChild(startNode));
	  }

	  public void getNodesInOrderHelper(BinaryTreeNode<Key,Value> node){
	    if (this.isExternal(node)){
	      return;
	    }
	    getNodesInOrderHelper(node.getLeftChild());
	    this.nodeList.add(node);
	    getNodesInOrderHelper(node.getRightChild());
	  }

	  public boolean isLeaf(BinaryTreeNode<Key,Value> node){
		  if(node==null) {
			  return false;
		  }
		 
	    return (this.isExternal(node.getRightChild()) && this.isExternal(node.getLeftChild()));
	  }

	}

 
