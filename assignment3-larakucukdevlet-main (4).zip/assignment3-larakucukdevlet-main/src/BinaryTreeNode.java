package code;

import java.util.Objects;

import given.Entry;

/*
 * The binary node class which extends the entry class.
 * This will be used in linked tree implementations
 * 
 */
public class BinaryTreeNode<Key, Value> extends Entry<Key, Value> {
	  protected Key k;
	  protected Value v;
	  protected BinaryTreeNode<Key,Value> leftChild;
	  protected BinaryTreeNode<Key,Value> rightChild;
	  protected BinaryTreeNode<Key,Value> parent;

	  public BinaryTreeNode(Key k, Value v) {
	    super(k, v);
	    /*
	     * 
	     * This constructor is needed for the autograder. You can fill the rest to your liking.
	     * YOUR CODE AFTER THIS:
	     * 
	     */
	    this.leftChild = null;
	    this.rightChild = null;
	    this.parent = null;
	  }

	  /*
	   * Other methods can be added here
	   */

	  public BinaryTreeNode<Key, Value> getLeftChild() {
	    return leftChild;
	  }

	  public void setLeftChild(BinaryTreeNode<Key, Value> leftChild) {
	    this.leftChild = leftChild;
	  }

	  public BinaryTreeNode<Key, Value> getRightChild() {
	    return rightChild;
	  }

	  public void setRightChild(BinaryTreeNode<Key, Value> rightChild) {
	    this.rightChild = rightChild;
	  }

	  public BinaryTreeNode<Key, Value> getParent() {
	    return parent;
	  }

	  public void setParent(BinaryTreeNode<Key, Value> parent) {
	    this.parent = parent;
	  }

	  public boolean hasLeftChild(){
	    return !Objects.isNull(this.getLeftChild());
	  }

	  public boolean hasRightChild(){
	    return !Objects.isNull(this.getRightChild());
	  }
	}
