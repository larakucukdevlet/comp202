package code;
import java.util.EmptyStackException;

public class PriorityQTester {
	  public static void test00()
	    {
	        System.out.println("\n---------------<Test 00: Create a new Priority Queue then Verify that size() is 0>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            if(pq.size()==0)
	            {
	                System.out.println("Test passed..PQ has zero size after initializatuin");
	            }
	            else{
	                System.out.println("Test failed..PQ has non-zero size after initializatuin");
	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to get the priortiy queue size");
	            exception.printStackTrace();
	            System.out.println("Possible causes:"
	            +"\n the size was not initilized correctly in the BinarySearchTree class "
	            +"\n the size was not set to null after initilization..e.g as a results of casting");

	        }
	        
	    }

	    public static void test01()
	    {
	        System.out.println("\n---------------<Test 01: Create a new Priority Queue then Verify that isEmpty() returns true>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            if(pq.isEmpty()==true)
	            {
	                System.out.println("Test passed..PQ isEmpty() method returns true after initializatuin");
	            }
	            else{
	                System.out.println("Test failed..PQ isEmpty() method returns false after initializatuin");
	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue isEmptyy() method");
	            exception.printStackTrace();
	            System.out.println("This method is implemented in the BinrarySearchTree class..so you need to review that implementaion first..Possible causes:"
	            +"\n the size was not set to null after initilization..e.g as a results of casting"
	            +"\n isEmpty() is refering to an initilized Search Tree object");
	        }
	        
	    }

	    public static void test02()
	    {
	        System.out.println("\n---------------<Test 02: Verify that the size equals to 1 after inserting a single node>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "Fist Node");
	            if(pq.size()==1)
	            {
	                System.out.println("Test passed..PQ size() returns 1 after inserting single node");
	            }
	            else{
	                System.out.println("Test failed..PQ size() returns "+ pq.size()+" after inserting single node.");
	                if(pq.size()==0)
	                {
	                    System.out.println("You probably forgot the update the Binary Search Tree size after inserting new node");
	                }
	                else if (pq.size()<0)
	                {
	                    System.out.println("It seems you decremented the Binary Search Tree size after inserting new node");
	                }
	                else{
	                    System.out.println("It seems you incremented the Binary Search Tree size more than one time after inserting new node");
	                }
	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue insert()/sizer() methods");
	            exception.printStackTrace();
	            System.out.println("This method mostly invokes another method implemented in the BinrarySearchTree class..so you need to review that implementaion first..Possible causes:"
	            +"\n You are trying to insert a null node"
	            +"\n You didn't handle the unset root node correctly in the tree..remeber that currently root should be null, since this is the first node to insert, it will become the root"
	            +"\n My adivce: check either put(), isExternal() or the method that is responsabile of inserting the root node (if you handle it in a different method)");
	        }
	    }

	    public static void test03()
	    {
	        System.out.println("\n---------------<Test 03: Verify that  sEmpty() method return false after inserting a single node>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "Fist Node");
	            if(pq.isEmpty()==false)
	            {
	                System.out.println("Test passed..PQ isEmpty() returns false after inserting single node");
	            }
	            else{
	                System.out.println("Test failed..PQ size() isEmpty() returns true after inserting single node");
	                    System.out.println("It seems you didn't increment the Binary Search Tree size after inserting new node"
	                    +"\n You probably needs to check the previouse test results..if passed, then isEmpty() is implemented incorrectly..o.w, fixing the previous test would fix this as well"
	                    );
	                }

	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue isEmpty() method");
	            exception.printStackTrace();
	        }
	    }

	    public static void test04()
	    {
	        System.out.println("\n---------------<Test 04: Verify that the size equals to 2 after inserting a two nodes>---------------");
	        System.out.println("Note: if you get stackoverflow or OutOfMemoryError exception here, then you need to revisit the calls to comparator, setLeftChild() method implementaion, or setRightChild() method implementaion ");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "Fist Node");
	            pq.insert(2, "Second Node");
	            if(pq.size()==2)
	            {
	                System.out.println("Test passed..PQ size() returns 2 after inserting single node");
	            }
	            else{
	                System.out.println("Test failed..PQ size() returns "+ pq.size()+" after inserting single node.");
	                if(pq.size()==0)
	                {
	                    System.out.println("You probably forgot the update the Binary Search Tree size after inserting the root and the second nodes");
	                }
	                else if (pq.size()==1)
	                {
	                    System.out.println("You probably forgot the update the Binary Search Tree size after inserting the root or the second nodes. \n If the previous test failed, then you definitly needs to fix the root node insertion, \n o.w you need to fix inserting the second node");
	                }
	                else{
	                    System.out.println("It seems you incremented the Binary Search Tree size more than one time after inserting new node");
	                }
	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue insert() method");
	            exception.printStackTrace();
	            System.out.println("This method mostly invokes another method implemented in the BinrarySearchTree class..so you need to review that implementaion first..Possible causes:"
	            +"\n You are trying to insert a null node"
	            +"\n You didn't handle the unset right/left node correctly in the tree..remeber that currently this node should be null"
	            +"\n My adivce: check either put(), isExternal() or the method that is responsabile of inserting the new node (if you handle it in a different method)");
	        }
	    }

	    public static void test05()
	    {
	        System.out.println("\n---------------<Test 05: Create a new Priority Queue then Verify that top() returns null or throughs EmptyStackException>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            if(pq.top()==null)
	            {
	                System.out.println("Test passed..PQ top() method returns null after initializatuin");
	            }
	            else{
	                System.out.println("Test failed..PQ isEmpty() method non null value after initializatuin");
	            }
	        }
	        catch(EmptyStackException exception){
	            System.out.println("Tested passed.. top() method throws EmptyStackException exception when the Q is empty ");
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue top() method while it's empty");
	            exception.printStackTrace();
	            System.out.println("This should be a trivial method, so I would suggest to surround the null check with try/catch statment");
	        }
	    }

	    public static void test06()
	    {
	        System.out.println("\n---------------<Test 06: Create a new Priority Queue then Verify that pop() returns null or throughs EmptyStackException>---------------");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            if(pq.pop()==null)
	            {
	                System.out.println("Test passed..PQ top() method returns null after initializatuin");
	            }
	            else{
	                System.out.println("Test failed..PQ isEmpty() method non null value after initializatuin");
	            }
	        }
	        catch(EmptyStackException exception){
	            System.out.println("Tested passed.. top() method throws EmptyStackException exception when the Q is empty ");
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue top() method while it's empty");
	            exception.printStackTrace();
	            System.out.println("This should be a trivial method, so I would suggest to surround the null check with try/catch statment");
	        }
	    }

	    public static void test07()
	    {
	        System.out.println("\n---------------<Test 07: Verify the functionality of the get() method>---------------");
	        System.out.println("Note: if you get stackoverflow or OutOfMemoryError exception here, then you need to revisit the calls to comparator, setLeftChild() method implementaion, or setRightChild() method implementaion ");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "A");
	            pq.insert(2, "B");
	            pq.insert(3, "C");
	            pq.insert(4, "D");
	            pq.insert(5, "E");
	           
	            if(pq.get(3)=="C")
	            {
	                System.out.println("Test passed. The retrieved valye by key matches the inserted one");
	            }
	            else{
	                System.out.println("Test failed. The retrieved valye by key doesn't match the inserted one");
	                System.out.println("Since either cause by the put() or the get() methods."
	                +"\nSince both methods should be implemented in the BinarySearchTree class, you should start by exploring them there"
	                +"\n Since a value was retrieved then it's mostly related to the way you check the node to insert the new node to or get the child node from (traverse the tree)"
	                +"\n in other words, the comparators calls then decisions"
	                );

	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue insert() or get() methods ");
	            exception.printStackTrace();
	            System.out.println("This is mostly to retrieve a value from a null node");
	        }
	    }

	    public static void test08()
	    {
	        System.out.println("\n---------------<Test 08: Verify the functionality of the remove() method>---------------");
	        System.out.println("Note: if you get stackoverflow or OutOfMemoryError exception here, then you need to revisit the calls to comparator, setLeftChild() method implementaion, or setRightChild() method implementaion ");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "A");
	            pq.insert(2, "B");
	            pq.insert(3, "C");
	            pq.insert(4, "D");
	            pq.insert(5, "E");
	           
	            pq.remove(3);
	            if(pq.get(3)==null)
	            {
	                if(pq.size()==4 && pq.get(1)=="A" && pq.get(2)=="B"&&pq.get(4)=="D"&&pq.get(5)=="E")
	                {
	                    System.out.println("Test passed. remove() method works as expected..the removed entry doesn't exist anymore and other nodes are still existing");
	                }
	                else
	                {
	                    System.out.println("Test failed. Entry with key = 3 was removed but other entries were also removed/added as well");
	                }
	            }
	            else{
	                System.out.println("Test failed. remove() mthod was not able to remove the entry by key");
	                System.out.println("Assuming the get() method is working well, this is definitly an issue in remove() method in BinarySeachTree class"
	                +"\n Again, you visit the treee traversal when looking for the value to be deleted, and realocating its children"
	                );

	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue remove() method");
	            exception.printStackTrace();
	            System.out.println("This is mostly related to retrieve/add children from/to null node");
	        }
	    }

	    public static void test09()
	    {
	        System.out.println("\n---------------<Test 09: Verify the functionality of the replaceKey() method>---------------");
	        System.out.println("Note: if you get stackoverflow or OutOfMemoryError exception here, then you need to revisit the calls to comparator, setLeftChild() method implementaion, or setRightChild() method implementaion ");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(1, "A");
	            pq.insert(2, "B");
	            pq.insert(3, "C");
	            pq.insert(4, "D");
	            pq.insert(5, "E");
	           
	            pq.replaceKey("C", 6);
	            if(pq.get(3)==null && pq.get(6)=="C")
	            {
	                if(pq.size()==5 && pq.get(1)=="A" && pq.get(2)=="B"&&pq.get(4)=="D"&&pq.get(5)=="E")
	                {
	                    System.out.println("Test passed. replaceKey() method works as expected..the value now has a new key and other nodes are still not touched");
	                }
	                else
	                {
	                    System.out.println("Test failed. Entry with value = C has a new key now  but other entries were also changed");
	                }
	            }
	            else{
	                System.out.println("Test failed. replaceKey() mthod was not the key of an exisitng entry");
	                System.out.println("Assuming the insert()/get() methods are working well, this is definitly an issue in replaceKey() method in the BSTBasedPQ class"
	                +"\n You probably invoke other exisitng methods in this class...make sure your are doing that right"
	                );

	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue remove() method");
	            exception.printStackTrace();
	            System.out.println("This is mostly related to retrieve/add children from/to null node");
	        }
	    }

	    public static void test10()
	    {
	        System.out.println("\n---------------<Test 10: Verify the functionality of the pop() method>---------------");
	        System.out.println("Note: if you get stackoverflow or OutOfMemoryError exception here, then you need to revisit the calls to comparator, getLeftChild() method implementaion, or getRightChild() method implementaion ");
	        try{
	            BSTBasedPQ<Integer, String> pq = new BSTBasedPQ<Integer, String>();
	            pq.insert(3, "C");
	            pq.insert(2, "B");
	            pq.insert(5, "E");
	            pq.insert(1, "A");
	            pq.insert(3, "C");
	            pq.insert(4, "D");
	            
	            if(pq.pop().getValue()=="A")
	            {
	                if(pq.size()==4 && pq.get(5)=="E" && pq.get(2)=="B"&&pq.get(3)=="C"&&pq.get(4)=="D")
	                {
	                    System.out.println("Test passed. replaceKey() method works as expected..and entry with the lowest priority value was retrieved");
	                }
	                else
	                {
	                    System.out.println("Test failed The entry with the lowest priority value was retrieved but other entries were touched as well");
	                }
	            }
	            else{
	                System.out.println("Test failed..the entry with the lowest priority value was not retrieved");
	                System.out.println("\n You probably invoke other exisitng methods in this class...make sure your are doing that right"
	                );

	            }
	        }
	        catch(Exception exception){
	            System.out.println("Tested failed.. the following exception thrown when trying to invoke the priortiy queue pop() method");
	            exception.printStackTrace();
	            System.out.println("This is mostly related to retrieve/add children from/to null node");
	        }
	    }

	    public static void main(String[] args) {
	        test00();
	        test01();
	        test02();
	        test03();
	        test04();
	        test05();
	        test06();
	        test07();
	        test08();
	        test09();
	        test10();
	    }
}