package code;

import given.Entry;
import given.iAdaptablePriorityQueue;

/*
 * Implement a binary search tree based priority queue
 * Do not try to create heap behavior (e.g. no need for a last node)
 * Just use default binary search tree properties
 */

public class BSTBasedPQ<Key, Value> extends BinarySearchTree<Key, Value> implements iAdaptablePriorityQueue<Key, Value> {

 /*public BSTBasedPQ(Key k, Value v) {
		super(k, v);
		// TODO Auto-generated constructor stub
	}*/

/*
   * 
   * YOUR CODE BELOW THIS
   * 
   */

 /* public BSTBasedPQ(Key k, Value v) {
    super(k, v);
  }*/
  



@Override
  public void insert(Key k, Value v) {
    // TODO Auto-generated method stub
    BinaryTreeNode<Key,Value> insertedNode = new BinaryTreeNode<>(k,v);
    this.insertHelper(insertedNode, this.getRoot());
    this.keySet.add(insertedNode.getKey());
  }

  @Override
  public Entry<Key, Value> pop() {
    // TODO Auto-generated method stub
    if (this.isEmpty()){
      return null;
    }

    BinaryTreeNode<Key, Value> returnNode = this.popHelper(this.rootNode);
    this.remove(returnNode.getKey());

    return returnNode;
  }

  @Override
  public Entry<Key, Value> top() {
    // TODO Auto-generated method stub
    if (this.isEmpty()){
      return null;
    }

    return this.popHelper(this.rootNode);
  }

  @Override
  public Key replaceKey(Entry<Key, Value> entry, Key k) {
    // TODO Auto-generated method stub
    BinaryTreeNode<Key,Value> foundNode = this.getNode(entry.getKey());
    if (foundNode.getValue().equals(entry.getValue())){
      this.remove(entry.getKey());
      this.insert(k, entry.getValue());
      return entry.getKey();
    }
    else{
      return null;
    }
  }

  @Override
  public Key replaceKey(Value v, Key k) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Value replaceValue(Entry<Key, Value> entry, Value v) {
    // TODO Auto-generated method stub
    Value returnedValue = entry.getValue();
    this.getNode(entry.getKey()).setValue(v);
    return returnedValue;
  }

  public void insertHelper(BinaryTreeNode<Key,Value> insertedNode, BinaryTreeNode<Key,Value> inspectedNode){
    if (this.isLeaf(inspectedNode)){
      if ((this.getComparator().compare(insertedNode.getKey(),inspectedNode.getKey())) < 0){
        inspectedNode.setLeftChild(insertedNode);
      }
      else{
        inspectedNode.setRightChild(insertedNode);
      }
      insertedNode.setParent(inspectedNode);
    }
    else{
      if (this.getComparator().compare(insertedNode.getKey(), inspectedNode.getKey()) < 0){
        this.insertHelper(insertedNode, inspectedNode.getLeftChild());
      }
      else if (this.getComparator().compare(insertedNode.getKey(), inspectedNode.getKey()) > 0) {
        this.insertHelper(insertedNode, insertedNode.getRightChild());
      }
    }
  }

  public BinaryTreeNode<Key, Value> popHelper(BinaryTreeNode<Key,Value> node){
    if (this.isExternal(getLeftChild(node))){
    	getLeftChild(node);
      return node;
    }
    else{
      return this.popHelper(getLeftChild(node));
    }
  }

}


