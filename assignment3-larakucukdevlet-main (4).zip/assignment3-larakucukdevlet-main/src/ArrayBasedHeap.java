package code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import given.Entry;
import given.iAdaptablePriorityQueue;

/*
 * Implement an array based heap
 * Note that you can just use Entry here!
 * 
 */
public class ArrayBasedHeap<Key, Value> implements iAdaptablePriorityQueue<Key, Value> {
	  
	  // Use this arraylist to store the nodes of the heap. 
	  // This is required for the auto-grader.
	  // It makes your implementation more verbose (e.g. nodes[i] vs nodes.get(i)) but then you do not have to deal with dynamic resizing
	  protected ArrayList<Entry<Key,Value>> nodes;
	  protected Comparator<Key> comparator;
	  
	  /*
	   * 
	   * YOUR CODE BELOW THIS
	   * 
	   */

	  @Override
	  public int size() {
	    // TODO Auto-generated method stub
	    return this.nodes.size();
	  }

	  @Override
	  public boolean isEmpty() {
	    // TODO Auto-generated method stub
	    return this.nodes.isEmpty();
	  }

	  @Override
	  public void setComparator(Comparator<Key> C) {
	    // TODO Auto-generated method stub
	    this.comparator = C;
	  }

	  @Override
	  public Comparator<Key> getComparator() {
	    // TODO Auto-generated method stub
	    return this.comparator;
	  }

	  @Override
	  public void insert(Key k, Value v) {
	    // TODO Auto-generated method stub
	    Entry<Key, Value> newEntry = new Entry<>(k,v);
	    this.nodes.add(newEntry);
	    this.upHeap(this.nodes.indexOf(newEntry));
	  }

	  @Override
	  public Entry<Key, Value> pop() {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }
	    Entry<Key, Value> returnedEntry = this.nodes.get(0);
	    Collections.swap(this.nodes, 0, (this.size()-1));
	    this.nodes.remove((this.size() - 1));
	    this.downHeap(0);
	    return returnedEntry;
	  }

	  @Override
	  public Entry<Key, Value> top() {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }
	    return this.nodes.get(0);
	  }

	  @Override
	  public Value remove(Key k) {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }

	    Value returnValue;

	    for (int i = 0; i<this.size(); i++){
	      if (this.getComparator().compare(k,this.nodes.get(i).getKey()) == 0){
	        returnValue = this.nodes.get(i).getValue();
	        Collections.swap(this.nodes, i, this.size()-1);
	        this.nodes.remove(this.size() - 1);
	        this.heapify();
	        return returnValue;
	      }
	    }
	    return null;
	  }

	  @Override
	  public Key replaceKey(Entry<Key, Value> entry, Key k) {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }
	    if (this.nodes.contains(entry)){
	      Entry<Key,Value> newEntry = new Entry<>(k, entry.getValue());
	      int entryIndex = this.nodes.indexOf(entry);
	      this.nodes.set(entryIndex, newEntry);
	      this.heapify();
	      return entry.getKey();
	    }
	    return null;
	  }

	  @Override
	  public Key replaceKey(Value v, Key k) {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }
	    for (int i = 0; i < this.size(); i++){
	      if (v.equals(this.nodes.get(i).getValue())){
	        Entry<Key,Value> newEntry = new Entry<>(k,v);
	        Key oldKey = this.nodes.get(i).getKey();
	        this.nodes.set(i, newEntry);
	        this.heapify();
	        return oldKey;
	      }
	    }
	    return null;

	  }

	  @Override
	  public Value replaceValue(Entry<Key, Value> entry, Value v) {
	    // TODO Auto-generated method stub
	    if (this.isEmpty()){
	      return null;
	    }
	    if (this.nodes.contains(entry)){
	      Entry<Key, Value> newEntry = new Entry<>(entry.getKey(),v);
	      int entryIndex = this.nodes.indexOf(entry);
	      this.nodes.set(entryIndex, newEntry);
	      this.heapify();
	      return entry.getValue();
	    }
	    return null;
	  }

	  public int parentOf(int index){
	    return ((index - 1)/2);
	  }

	  public int leftChildOf(int index){
	    return 2*index + 1;
	  }

	  public int rightChildOf(int index){
	    return 2*index + 2;
	  }

	  public boolean hasLeftChild(int index){
	    return this.leftChildOf(index) < this.nodes.size();
	  }

	  public boolean hasRightChild(int index){
	    return this.rightChildOf(index) < this.nodes.size();
	  }

	  public void upHeap(int index){

	    int parentIndex;

	    while (index > 0){
	      parentIndex = this.parentOf(index);
	      if (this.getComparator().compare(this.nodes.get(index).getKey(), this.nodes.get(parentIndex).getKey()) >= 0){
	        break;
	      }
	      Collections.swap(this.nodes, index, parentIndex);
	      index = parentIndex;
	    }
	  }

	  public void downHeap(int index){

	    int smallChild;
	    int rc;

	    while (this.hasLeftChild(index)){
	      smallChild = this.leftChildOf(index);
	      if (this.hasRightChild(index)){
	        rc = rightChildOf(index);

	        if (this.getComparator().compare(this.nodes.get(rc).getKey(), this.nodes.get(smallChild).getKey()) < 0){
	          smallChild = rc;
	        }
	      }
	      if (this.getComparator().compare(this.nodes.get(smallChild).getKey(),this.nodes.get(index).getKey()) >= 0){
	        break;
	      }
	      Collections.swap(this.nodes, index, smallChild);
	      index = smallChild;
	    }
	  }

	  public void heapify(){
	    for (int i = this.nodes.size(); i >= 0; i--){
	      this.downHeap(i);
	    }
	  }

	}


