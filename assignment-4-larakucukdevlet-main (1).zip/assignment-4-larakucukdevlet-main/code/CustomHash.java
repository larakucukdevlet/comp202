package code;


public class CustomHash {

    public static int customHashCode(Object obj) {
        if (obj == null) {
            return 0;
        }

    
        int hash = 0;
        
        String k = obj.toString();
        
        for (int i = 0; i < k.length(); i++) {
            hash = 1331 * hash + k.charAt(i);
        }
        
        return hash;
        
        
    }

}
