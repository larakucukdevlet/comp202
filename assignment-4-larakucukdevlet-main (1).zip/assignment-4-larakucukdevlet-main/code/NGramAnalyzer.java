package code;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import code.HashMapDH;
import given.HashEntry;

public class NGramAnalyzer {

    private HashMapDH<String, Integer> nGramMap;
    private HashMapDH<String, HashMapDH<String, Integer>> prefixMap;
    private int n;

    public NGramAnalyzer(int n) {
        this.n = n;
        // initialize nGramMap and prefixMap here!
        nGramMap= new HashMapDH<String, Integer>();
        prefixMap = new HashMapDH<String, HashMapDH<String, Integer>>();
    }

    public HashMapDH<String, Integer> getNextWordMap(String prefix) {
        return prefixMap.get(prefix);
    }

    public List<String> preprocess(String inputFile) {
        List<String> sentences = new ArrayList<>();
        try ( BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim().toLowerCase();
                line = removePunctuation(line);
                String[] tokens = line.split("\\.");
                for (String token : tokens) {
                    sentences.add(token.trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sentences;
    }

    private String removePunctuation(String line) {
        Pattern pattern = Pattern.compile("[^a-zA-Z ]");
        Matcher matcher = pattern.matcher(line);
        return matcher.replaceAll("");
    }

    /*
     * This function updates nGramMap given a list of preprocessed
     * sentences. 
     * It uses n-grams as keys and updates the count of encountered n-grams;
     * You can use Java StringBuilder or simply String concatenation 
     *   to construct n-grams. 
     */
    public void buildNGram(List<String> sentences) {
        for (String sentence : sentences) {
            String[] words = sentence.split("\\s+");
            int len=words.length;
            for (int a = 0; a < len - n + 1; a++) {
            	StringBuilder s = new StringBuilder();
            	for(int b = a; b<a+n; b++) {
            		s.append(words[b]).append(" ");
            	}
            	String gram = s.toString().trim();
            	Integer c = nGramMap.get(gram);
            	if(c==null) {
            		c = 0;
            	}
            	nGramMap.put(gram,c+1);
            }
            
            
            
        }
    }

    public int countTwoWordCollocation(String firstWord, String secondWord) {
        String collocation = firstWord + " " + secondWord;
        Integer count = nGramMap.get(collocation);
        return count == null ? 0 : count;
    }

    
    // given another instance of NGramAnalyzerm this function computes the
    // similarty score between their nGramMap(s). Maximum score is 1, 
    // if they are absolutely same. 
    public double compareNGram(NGramAnalyzer otherAnalyzer) {
        int intersection = 0; // the number of intersected ngrams
        int union = 0; // the number of total ngrams
        
        for (String key : nGramMap.keySet()) {
            Integer c1 = nGramMap.get(key);
            Integer c2 = otherAnalyzer.nGramMap.get(key);
            if(c1 != null && c2 != null) {
        		intersection += Math.min(c1, c2);
            	union += Math.max(c1, c2);
        	}else if(c2 != null) {
        		union += c2.intValue();
        		
        	}else if(c1 != null) {
        		union += c1.intValue();
        	}
        }
      

        // to scale the number to 1, we need to add the values of the keys that
        // are present in the other nGramMap, but not this one
        for (String key : otherAnalyzer.nGramMap.keySet()) {
            if (nGramMap.get(key) == null) {
                union += otherAnalyzer.nGramMap.get(key);
            }
        }

        return (double) intersection / union;
    }

    
    /*
     * This function returns a List of topN most frequent NGrams in nGramMap 
     *     You can use any sorting function (even the built-in Java ones)
     * 
     */
    public List<String> getMostFrequentNGrams(int topN) {

        List<String> mostFrequentNGrams = new ArrayList<>();
        
        List<String> k = (List<String>) nGramMap.keySet();
       

       Collections.sort(k, (k1, k2) -> nGramMap.get(k2).compareTo(nGramMap.get(k1)));
       
       for(int i=0; i < topN && i< k.size(); i++) {
       	mostFrequentNGrams.add(k.get(i));
       }
     
        return mostFrequentNGrams;
    }

    
    /*
     * This function updates prefixMap given a list of preprocessed
     *   sentences. It's purpose is to count the number of times a specific 
     *   last word (suffix) in the n-gram was preceded by every prefix 
     *   (an n-gram of length n-1, let's call it [n-1]-gram).
     * As you can infer from the data types of prefixMap, it uses a prefix
     *   [n-1]-grams as keys which map to another HashMapDH (value)
     * Each HashMapDH that serves as a value stores the words (suffixes) that 
     *   follow the "key" prefixes. In this HashMapDH each key is a suffix, 
     *   while the value is the count of cases when this suffix was
     *   encountered after the n-gram. (Read the pdf for an example)
     * 
     */
    public void buildPrefixMap(List<String> sentences) {
        for (String sentence : sentences) {
            String[] words = sentence.split("\\s+");
            
            for (int i = 0; i < words.length - n + 1; i++) {
                StringBuilder s = new StringBuilder();
                for (int j = i; j < i + n - 1; j++) {
                    s.append(words[j]).append(" ");
                }
              
                String prefix = s.toString().trim(); 
                String suffix = words[i + n - 1];
                HashMapDH<String, Integer> suffixMap = prefixMap.get(prefix);
                if(suffixMap == null) {
                	suffixMap = new HashMapDH<String, Integer>();
                }
                Integer count = suffixMap.get(suffix);
                if(count==null) {
                	count=0;
                	
                }
               
                suffixMap.put(suffix, count + 1);
                prefixMap.put(prefix, suffixMap);
            }  
            
        }
    }

}
