
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=11064922&assignment_repo_type=AssignmentRepo)
# comp202_2023_spring_HW4

## to check the results of autograding, see under the "Actions" tab
## if you do not pass the ithub's autograding, it means that you are not getting the test cases correctly, but the output you get in the console can say whether you are getting the HashMapTests and NGramBuilder tests right

You only need to work on the files inside the "code" directory. 
