package code;

/* 
 * ASSIGNMENT 2
 * AUTHOR:  <Lara Gul Kucukdevlet>
 * Class : LLDeque
 *
 * You are not allowed to use Java containers!
 * You must implement the linked list yourself
 * Note that it should be a doubly linked list
 *
 * MODIFY 
 * 
 * */

import given.iDeque;
import java.util.Iterator;
import java.util.NoSuchElementException;

import given.Util;

//If you have been following the class, it should be obvious by now how to implement a Deque wth a doubly linked list
public class LLDeque<E> implements iDeque<E> {
  
  //Use sentinel nodes. See slides if needed
  private Node<E> header;
  private Node<E> trailer;
  private int size; //ben ekledim
  /*
   * ADD FIELDS IF NEEDED
   */

  // The nested node class, provided for your convenience. Feel free to modify
  private class Node<T> {
    private T element;
    private Node<T> next;
    private Node<T> prev;
    private int size;
    /*
     * ADD FIELDS IF NEEDED
     */
    
    Node(T d, Node<T> n, Node<T> p) {
      element = d;
      next = n;
      prev = p;
    }
    
    /*
     * ADD METHODS IF NEEDED
     */
  }
  
  public LLDeque() {
    //Remember how we initialized the sentinel nodes
    header  = new Node<E>(null, null, header);
    trailer = new Node<E>(null, trailer, header);
    header.next = trailer;
    size=0;
    
    /*
     * ADD CODE IF NEEDED
     */
  }
  
  public String toString() {
	  if(isEmpty())
	      return "";
	    StringBuilder sb = new StringBuilder(1000);
	    Node<E> tmp = header.next;
	    while(tmp.next != trailer) {
	      sb.append(tmp.element.toString());
	      sb.append("\n");
	      tmp = tmp.next;
	    }
	    sb.append(tmp.element.toString());
	    return sb.toString();
  }
  
  /*
   * ADD METHODS IF NEEDED
   */
  
  /*
   * Below are the interface methods to be overriden
   */

  @Override
  public int size() {  //DOĞRU
	  Node<E>current = header.next;
	  int size=0;
	  while(current!=trailer) {
		  size++;
		  current=current.next;
	  }	  
	  return size;
    // TODO Auto-generated method stub
   // Util.NotImplementedYetSoft();
    //return 0;
  }

  @Override
  public boolean isEmpty() {
	  return header.next==trailer;
     //TODO Auto-generated method stub
    //Util.NotImplementedYetSoft();
    //return false;
  }

  @Override
  public void addFront(E o) {   //BİR DAHA ABK
	  Node<E> after = header.next;
	  Node<E> fr= new Node<E>(o,after,header);
	  after.prev=fr;
	  header.next=fr;
	  size++;
    // TODO Auto-generated method stub
    //Util.NotImplementedYetSoft();
  }

  @Override
  public E removeFront() {
	  if(isEmpty()) {
	    	return null;
	    }
	    Node<E> fr= header.next;
	    header.next=fr.next;
	    fr.next.prev=header;
	    size--;
	    return fr.element;
    // TODO Auto-generated method stub
    //Util.NotImplementedYetSoft();
    //return null;
  }

  @Override
  public E front() {
	  if(isEmpty()) {
		  return null;
		  
	  }
	  return header.next.element;
    // TODO Auto-generated method stub
    //Util.NotImplementedYetSoft();
    //return null;
  }

  @Override
  public void addBehind(E o) {
	    Node<E> now = trailer.prev;
	    Node<E> lastNode = new Node<E>(o, trailer, now);
	    now.next = lastNode;
	    trailer.prev =lastNode;
	    size++;
    // TODO Auto-generated method stub
   // Util.NotImplementedYetSoft();
  }

  @Override
  public E removeBehind() {
	  if (isEmpty()) {
	      return null;
	    }
	    Node<E> lastNode = trailer.prev;
	    trailer.prev = lastNode.prev;
	    lastNode.prev.next = trailer;
	    size--;
	    return lastNode.element;

    // TODO Auto-generated method stub
   // Util.NotImplementedYetSoft();
    //return null;
  }

  @Override
  public E behind() {
	  if (isEmpty()) {
	      return null;
	    }
	    return trailer.prev.element;
    // TODO Auto-generated method stub
    //Util.NotImplementedYetSoft();
    //return null;
  }

  @Override
  public void clear() {
	  header.next = trailer;
	  trailer.prev = header;
    // TODO Auto-generated method stub
    
  }
  
  @Override
  public Iterator<E> iterator() {
	  return new LLDequeIterator();
    // TODO Auto-generated method stub
    //Hint: Fill in the LLDequeIterator given below and return a new instance of it
    //return null;
  }
  
  private final class LLDequeIterator implements Iterator<E> {
	  private Node<E> cr;
	  public LLDequeIterator() {
		  cr =header.next;
	  }
    /*
     * 
     * ADD A CONSTRUCTOR IF NEEDED
     * Note that you can freely access everything about the outer class!
     * 
     */

    @Override
    public boolean hasNext() {  //sorun var
    	return cr!=trailer;//cr.next != null;
      // TODO Auto-generated method stub
     ///return false;
    }

    @Override
    public E next() {
    	if (!hasNext()) {
            throw new NoSuchElementException();
        }
        E element = cr.element;
        cr = cr.next;
        return element;
      // TODO Auto-generated method stub
     // return null;
    }        
  }
  
}
