package code;

import given.AbstractArraySort;

public class InsertionSort<K extends Comparable<K>> extends AbstractArraySort<K> {

  public InsertionSort() {
    name = "Insertionsort";
  }

  @Override
  public void sort(K[] inputArray) {
    for (int i = 1; i < inputArray.length; i++) { //start from 2nd element from array
	      K tempCurr = inputArray[i]; //copy of to temporary value 
	      int j =i-1 ; //one space before current

	      // Move elements greater than the key to the right
	      while (j >= 0 && compare(inputArray[j], tempCurr)>0) { //stop going back when hit the beginning of array. //Compare it with compare method becasue otherwise cannot compare K value
	        swap(inputArray, j + 1, j); //swap j+1 with j
	        j--;
	      }

	  
	      inputArray[j + 1] = tempCurr;
	  
    // TODO: Implement the insertion sort algorithm [ascending order]
	    }
  }

}
