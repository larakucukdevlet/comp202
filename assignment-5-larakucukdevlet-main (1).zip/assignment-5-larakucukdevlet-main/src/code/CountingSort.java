package code;

import given.AbstractArraySort;

/*
 * Implement the counting-sort algorithm here. You can look at the slides for the pseudo-codes.
 * You do not have to use swap or compare from the AbstractArraySort here
 * 
 * You may need to cast any K to Integer
 * 
 */

public class CountingSort<K extends Comparable<K>> extends AbstractArraySort<K> {

  // Add any fields here

  public CountingSort() {
    name = "Countingsort";
  }

  @Override
  public void sort(K[] inputArray) {

    if (inputArray == null) {
      System.out.println("Null array");
      return;
    }
    else if (inputArray.length < 1) {
      System.out.println("Empty array");
      return;
    }

   
    int min= (int) inputArray[0];
    int max= (int)inputArray[0];
    for (int i = 1; i < inputArray.length; i++) {
        int element = (int) inputArray[i];
        if (element < min) {
          min = element;
        }
        if (element > max) {
          max = element;
        }
    }
    int[] countArray = new int[max - min + 1];

    // Count the occurrences of each element
    for (int i = 0; i < inputArray.length; i++) {
      int element = (int) inputArray[i];
      countArray[element - min]++;
    }

   
    for (int i = 1; i < countArray.length; i++) {
      countArray[i] += countArray[i - 1];
    }


   
    @SuppressWarnings("unchecked")
	K[] tempArray = (K[]) new Comparable[inputArray.length]; //temporary array

    // Build the sorted array
    for (int i = inputArray.length - 1; i >= 0; i--) {
      int element = (int) inputArray[i];
      int index = countArray[element - min] - 1;
      tempArray[index] = inputArray[i];
      countArray[element - min]--;
    }

   
    System.arraycopy(tempArray, 0, inputArray, 0, inputArray.length); //copy the sorted array
  }
    

  

}
