package code;

import given.AbstractArraySort;

/*
 * Implement the tim-sort algorithm here. You can look at the slides for the pseudo-codes.
 * Make sure to use the swap and compare functions given in the AbstractArraySort!
 * 
 * 
 */

public class TimSort<K extends Comparable<K>> extends AbstractArraySort<K> {

  // Add any fields here

  static int MIN_MERGE = 32;

  public TimSort() {
    name = "Timsort";

    // Initialize anything else here
  }

  @Override
  public void sort(K[] inputArray) {
	  int n = inputArray.length;

	  for (int i = 0; i < n; i += MIN_MERGE) {
	    insertionSort(inputArray, i, Math.min(i + MIN_MERGE - 1, n - 1));
	  }


	  for (int size = MIN_MERGE; size < n; size *= 2) {
	    for (int lo = 0; lo < n ; lo += 2 * size) {
	      int mid = lo + size - 1;
	      int hi = Math.min(lo + 2 * size - 1, n - 1);
	      if(mid<hi) {
	    	  merge(inputArray, lo, mid, hi);
	      }
	      
	    }
	  }
    // TODO: Implement the tim-sort algorithm [ascending order]

    // Suggested implementation [See the pdf for more details]]:
    // 1. Sort individual subarrays of size MIN_MERGE (using insertion sort)
    // 2.1 Start merging from size MIN_MERGE (using merge function)
    // 2.2 Double the size on each iteration

  }


  public void merge(K[] inputArray, int lo, int mid, int hi) { //bu da tmam
	    int n1 = mid - lo + 1;
	    int n2 = hi - mid;

	    K[] left = (K[]) new Comparable[n1];
	    K[] right = (K[]) new Comparable[n2];

	    for (int i = 0; i < n1; i++) {
	      left[i] = inputArray[lo + i]; //store the divided first part
	    }

	    for (int j = 0; j < n2; j++) {
	      right[j] = inputArray[mid + 1 + j]; //store the second part 
	    }

	    int i = 0, j = 0, k = lo;

	    while (i < n1 && j < n2) {
	      if (compare(left[i], right[j]) <= 0) {
	        inputArray[k] = left[i];
	        i++;
	      } else {
	        inputArray[k] = right[j];
	        j++;
	      }
	      k++;
	    }

	    while (i < n1) {
	      inputArray[k] = left[i];
	      i++;
	      k++;
	    }

	    while (j < n2) {
	      inputArray[k] = right[j];
	      j++;
	      k++;
	    }


  }

  // It's just the insertion sort we know but with the lo and hi parameters as an
  // extra. (Recommended for the implementation)

  protected void insertionSort(K[] inputArray, int lo, int hi) { //bu tamam
	  for (int i = lo + 1; i <= hi; i++) {
		    K key = inputArray[i];
		    int j = i - 1;
		    while (j >= lo && compare(inputArray[j], key) > 0) {
		      swap(inputArray, j + 1, j); // Swap elements using the swap() method
		      j--;
		    }
		    inputArray[j + 1] = key;
		  }

  }

 

}
