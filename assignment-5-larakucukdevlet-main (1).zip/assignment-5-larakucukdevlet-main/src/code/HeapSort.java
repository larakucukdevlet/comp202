package code;

import given.AbstractArraySort;

/*
 * Implement the heap-sort algorithm here. You can look at the slides for the pseudo-code.
 * Make sure to use the swap and compare functions given in the AbstractArraySort!
 * 
 */

public class HeapSort<K extends Comparable<K>> extends AbstractArraySort<K> {
	
  // Add any fields here
	
	int size;
	K[] inputArray;

  public HeapSort(int size) {
	this.size = inputArray.length;
}

public HeapSort() {
    name = "Heapsort";
    

    // Initialize anything else here
  }

  @Override
  public void sort(K[] inputArray) {
	  heapify(inputArray);
	  for (int i = inputArray.length - 1; i > 0; i--) {
	       
	        swap(inputArray, 0, i);
	           

	        downheap(inputArray, 0, i-1);
	    }

  }


  public void heapify(K[] inputArray) {
	  int n = inputArray.length;

	    // Build the heap (rearrange the array)
	    for (int i = n / 2 - 1; i >=0; i--) {
	      downheap(inputArray, i, n-1);
	    }
	  
		
		  
    // TODO: Heapify the array. See the slides for the pseudo-code.

  }

  // The below methods are given given as suggestion. You do not need to use them.
  // Feel free to add more methods

  protected void downheap(K[] inputArray, int i, int n) {
		 int largest=i;
		 int left=(2*i)+1;
		 int right=(2*i)+2;
		 if (left <= n && compare(inputArray[left],inputArray[largest]) > 0) {
		      largest = left;
		 }

		    // If right child is larger than largest 
		 if (right <= n && compare(inputArray[right],inputArray[largest]) > 0) {
		    largest = right;
		 }

		    // If largest is not root
		 if (largest != i) {
		    // Swap the elements
		    swap(inputArray, i, largest);

		      // Recursively downheap the affected subtree
		    downheap(inputArray, largest, n);
		 }
	  
		    
	  
	  }
  
  /*protected void swap(K[] arr, int pos1, int pos2) {
	    
	    K temp = arr[pos1];
	    arr[pos1] = arr[pos2];
	    arr[pos2] = temp;
	  }*/
 
}
