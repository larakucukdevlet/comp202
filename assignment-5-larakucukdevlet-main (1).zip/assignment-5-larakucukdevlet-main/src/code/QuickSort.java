package code;

import java.util.Scanner;

import given.AbstractArraySort;
//arrayden herhangi bir pivot seç(sayı).
//seçtiğim pivottan küçük sayıları pivotun soluna büyükleri sağına koyucam.(partioning)
//sonra recursive olacak şekilde pivotun önce solunda kalan ksıımdaki elementlerden pivot seçip aynı adımı uyguluyoruz.
//sonra solda seçtiğimiz pivotun sağı ve solu için aynı şeyi yapıyoruz.


/*
 * Implement the quick-sort algorithm here. You can look at the slides for the pseudo-codes.
 * Make sure to use the swap and compare functions given in the AbstractArraySort!
 * 
 */

public class QuickSort<K extends Comparable<K>> extends AbstractArraySort<K> {
  // Add any fields here

  public QuickSort() {
    name = "Quicksort";

    // Initialize anything else here
  }

  // useful if we want to return a pair of indices from the partition function.
  // You do not need to use this if you are just returning and integer from the
  // partition
  public class indexPair {
    public int p1, p2; //pointers to right portion and left portion of array

    indexPair(int pos1, int pos2) {
      p1 = pos1;
      p2 = pos2;
    }

    public String toString() {
      return "(" + Integer.toString(p1) + ", " + Integer.toString(p2) + ")";
    }
  }
  
  @Override
  public void sort(K[] inputArray) {
	 
	  quickSort(inputArray,0,inputArray.length-1); //burda sadece quickSortu çağırıyoruz
	
	  
	  
	  
	 
    // TODO:: Implement the quicksort algorithm here [ascending order]

    // Suggestion:
    // Implement the helper method quickSort() below and just call it once here.

  }

  public indexPair partition(K[] inputArray, int lo, int hi, int p) {
	  //   p=pickPivot(inputArray,lo,hi); // p değişkeni pivotu veriyor
	  K pivot = inputArray[p];

	   swap(inputArray,p,hi); //pivotu sona attım
	   //  System.out.println(p);
	   int p1=lo;//left pointer to sort
	   int p2=hi-1; //right pointer to sort
	    //System.out.println("lo: " + lo + ", hi: " + hi);
	     while (p1 <= p2) {
	         if (compare(inputArray[p1], pivot) <= 0 ) {
	             p1++;// pivottan küçük olduğu sürece pivotun başından sonuna doğru arttır.
	         }
	         else if (compare(inputArray[p2], pivot) > 0 ) {
	             p2--;//soldakiler pivottan büyük olduğu sürece geriye doğru git sondan
	         }
	         else  {
	             swap(inputArray, p1, p2);
	             p1++;
	             p2--;
	         }
	       
	    }
	     swap(inputArray,p1,hi);
	     return new indexPair(p1-1,p1+1);
	  /*K pivot= inputArray[p];
	  //p=pickPivot(inputArray,lo,hi); // p değişkeni pivotu veriyor
	  swap(inputArray,p,hi); //pivotu sona attım
	//  System.out.println(p);
	 
	    swap(inputArray,p1,hi);
	    return new indexPair(p1-1,p1+1);*/
	    
	           
	        	

  }

  /*
   * Alternative, if you are just returning an integer
   * public int partition(K[] inputArray, int lo, int hi, int p)
   * {
   * //TODO:: Implement a partitioning function here
   * return null;
   * }
   */

  // The below methods are given given as suggestion. You do not need to use them.
  // Feel free to add more methods
  protected int pickPivot(K[] inputArray, int lo, int hi) { 
	  int pivot=lo;
	
	    
	  return pivot;
    // TODO: Pick a pivot selection method and implement it
  }

  protected void quickSort(K[] inputArray, int lo, int hi) { //array, lowIndex and Hıghindex
	  if (lo < hi) {
		    int p=pickPivot(inputArray,lo,hi);
		    indexPair indexPair = partition(inputArray, lo, hi,p); // Use lo as the initial pivot index
	        quickSort(inputArray, lo, indexPair.p1);
	        quickSort(inputArray, indexPair.p2, hi);
	    }
	      
		 // System.out.println("lo: " + lo + ", hi: " + hi);
		  //int p= pickPivot(inputArray,lo,hi);
		
		  
		  
	  
    // TODO: Implement the quicksort here with it's recursive logic and
    // just call it once in the sort() function.

  }


}
